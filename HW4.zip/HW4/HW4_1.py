import numpy as np
from numpy import *
import pandas as pd
from numpy import linalg as la
import matplotlib.pyplot as plt
from scipy.sparse.linalg import eigs
import math


def top_team(w,step,M,w_inf):
 if step == 10000:
  w_diff = []
  for t in range(step):
   w = w.dot(M)
   tmp = np.abs(w - w_inf)
   w_diff.append(np.sum(tmp))
  print(w_inf)

  plt.plot(range(1,10001),w_diff)
  plt.figure(1)
  plt.xticks(np.linspace(1, 10000, 10))
  plt.xlabel('10000 steps')
  plt.ylabel('∥wt −w∞∥1')
  plt.title('∥wt −w∞∥1 function of t')
  plt.show()
 else:
  for t in range(step):
   w = w.dot(M)
 # print(w.shape)
 # print(type(w))
 # print(w)

 sort_index = np.argsort(-w)[:25]
 sort_index = sort_index.tolist()
 sort_w = w[sort_index]
 # print(type(sort_index[0]))
 # print(sort_w)
 top_name = teamname[sort_index]
 # print(top_name)

 final_res = list(zip(top_name, sort_w))
 return final_res



teamscores = np.loadtxt(open("CFB2019_scores.csv","rb"),delimiter=",",skiprows=0)
# print(np.shape(teamscores))
# print(type(teamscores[0][0]))

teamname = []
with open("TeamNames.txt") as fdata:
 for line in fdata.readlines():
  line = line.strip('\n')
  teamname.append(line)
fdata.close()
# print(len(teamname))
teamname = np.array(teamname)
# print(teamname)
num_team = len(teamname)

M_hat = np.repeat(float(0), 769 * 769).reshape((769, 769))
# print(M_hat.shape)
# print("M_hat",M_hat)

for row in teamscores:
 teamA, scoreA, teamB, scoreB = int(row[0]), int(row[1]), int(row[2]), int(row[3])
 # print(teamA, scoreA, teamB, scoreB)
 # break
 # row index = team num -1
 i = teamA -1
 j = teamB -1
 # print(scoreA > scoreB)
 A_win = int(scoreA > scoreB)
 w_A = scoreA / (scoreA + scoreB)
 w_B = scoreB / (scoreA + scoreB)
 M_hat[i][i] += A_win + w_A
 M_hat[j][j] += (1 - A_win) + w_B
 M_hat[i][j] += (1 - A_win) + w_B
 M_hat[j][i] += A_win + w_A
 # print(w_A)
 # print(M_hat[i][i])
 # break


# print(M_hat[0])
# print(np.sum(M_hat, axis=1).reshape(-1,1))
M = M_hat / np.sum(M_hat, axis=1).reshape(-1,1) ##normalize
# print(M)

# print(num_team)
w = np.array([1/ num_team for i in range(num_team)])
# print(w.shape)


# w_inf = eigs(M.T,1)[1].flatten()
u1 = eigs(M.T,1)[1].flatten()
# print(u1.shape)
sum_u = np.sum(u1)
w_inf = u1 / sum_u
print(w_inf)
#


 # print(final_res)

# res10 = top_team(w,10,M,w_inf)
# res100 = top_team(w,100,M,w_inf)
# res1000 = top_team(w,1000,M,w_inf)
res10000 = top_team(w,10000,M,w_inf)





#
#
# # print(res10)
# # # col_name = ["rank","step 10"]
# ans10 =pd.DataFrame(res10)
# print(ans10)
# # ans10.to_csv('result10.csv',index = False)
# # #
# ans100 =pd.DataFrame(res100)
# print(ans100)
# # # # ans100.to_csv('result100.csv',index = False)
# #
# ans1000 =pd.DataFrame(res1000)
# print(ans1000)
# # # ans1000.to_csv('result1000.csv',index = False)
# #
ans10000 =pd.DataFrame(res10000)
# print(ans10000)
# # # ans10000.to_csv('result10000.csv',index = False)
# #
