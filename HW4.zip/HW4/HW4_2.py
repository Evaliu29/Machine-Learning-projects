import numpy as np
from numpy import *
import pandas as pd
from numpy import linalg as la
import matplotlib.pyplot as plt
from scipy.sparse.linalg import eigs
import math


##N = 3012, M = 8447, K = 25, W = N * K,H = K * M
##initialization of W, H
wordnum = 3012
docnum = 8447
K = 25
W = np.random.uniform(1,2,(wordnum,K))
H = np.random.uniform(1,2,(K,docnum))

##get X
docs = []
j = 0
X = np.zeros((wordnum,docnum)).astype(int)
# print(X.shape)
with open("nyt_data.txt") as fdata:
 for line in fdata.readlines():
     # print(line)
     doc = line.strip('\n')
     doc_info  = doc.split(',')
     # print(doc)
     for w in doc_info:
         w = w.split(":")
         # print(type(w[0]))
         # print(type(int(w[1])))
         X[int(w[0])-1][j] = int(w[1])
         # print(X[int(w[0])-1][j])
         # break
     j += 1
     docs.append(doc)
     # break
fdata.close()
# print(X)
# print(docs)
# print(len(docs))

##get words
vocabs = []
with open("nyt_vocab.dat") as fvoc:
 for line in fvoc.readlines():
     # print(line)
    line = line.strip('\n')
    vocabs.append(line)
 # print(vocabs)
vocabs = np.array(vocabs)
fvoc.close()

iter = 100
obj_ans = []

WH = W.dot(H)
# print(WH.shape)
tmp = X / (WH + 1e-16)

for i in range(iter):

    ##update H
    H = np.multiply(H, W.T.dot(tmp))/(np.sum(W,axis=0).reshape(K,1))
    # print(H)
    WH = W.dot(H)
    tmp = X/(WH+1e-16)
    W = np.multiply(W, tmp.dot(H.T))/np.sum(H,axis=1).reshape(1,K)
    # print(W.shape)
    WH = W.dot(H)
    tmp = X / (WH + 1e-16)

    obj_func = np.sum(np.multiply(X,np.log(1/(WH+1e-16))) + WH)
    obj_ans.append(obj_func)
# print(obj_ans)
# plt.plot(range(1,101),obj_ans)
# plt.figure(1)
# plt.xticks(np.linspace(1, 100,11))
# plt.xlabel('100 iterations')
# plt.ylabel('Objective function')
# plt.title('Objective as a function of iteration')
# plt.show()
def sort_W(col):
    index = np.argsort(-col)[:10]
    return index
##part b##
W = W / np.sum(W, axis=0).reshape(1,-1) ##normalize

sort_index = np.apply_along_axis(sort_W, 0, W)
# print(sort_index)
# print(sort_index.shape)
#sort_index : 10*25

res =pd.DataFrame(index=range(10),
                              columns=['Topic %d'%i for i in range(1,26)])
for col in range(sort_index.shape[1]):
    word_index = sort_index[:,col]

    # print(type(word_index))
    # print(sort_index[:,col])
    weight = W[word_index,col]
    # print(weight)
    # word_index = word_index.tolist()
    words = vocabs[word_index]
    # print(words)
    pair = list(zip(words,weight))
    # print(pair)

    res.iloc[:,col] = pair
    # break

# print(res)
res.to_csv("result_2.csv", index = False)
 # results.iloc[:,i] = list(zip([format(x, '.3f') for x in
 #                                                    self.W[word_idx[:,i],i]],
 #                                        self.words[word_idx[:,i]]))